import javax.swing.*;
public class LoginPageGUI extends JFrame{
    private JPanel myPanel;
    private JLabel topLabel;
    private JTextField textField1;
    private JPasswordField passwordField;
    private JLabel passLabel;
    private JButton loginButton;
    private JLabel userLabel;

    public LoginPageGUI(String title) {
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(myPanel);
        this.pack();
    }

}
