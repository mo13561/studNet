public class Comment {
    private String text;
    private String commentID;
    private String timePosted;
    private UserInfo commenter;

    public String getCommentID() {
        return commentID;
    }

    public String getText() {
        return text;
    }

    public String getTimePosted() {
        return timePosted;
    }

    public void setCommentID(String commentID) {
        this.commentID = commentID;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setTimePosted(String timePosted) {
        this.timePosted = timePosted;
    }

    public Comment(String text, String commentID, String timePosted) {
        setCommentID(commentID);
        setText(text);
        setTimePosted(timePosted);
    }
}
