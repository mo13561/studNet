public class Forum {
    UserInfo person1 = new UserInfo("Akshan", "grapplinghook", 13562);
    Discussion disc1 = new Discussion("What is x?", "Question", "ongoing", person1);
}
