import com.sun.source.tree.UsesTree;

public class Discussion {
    private String title;
    private String type;
    private String status;
    private String tag;
    private UserInfo discStarter;

    public Discussion(String discTitle, String discType, String discStatus, UserInfo discStarter) {
        setStatus(discStatus);
        setTitle(discTitle);
        setType(discType);
        setDiscStarter(discStarter);
    }

    public void setDiscStarter(UserInfo discStarter) {
        this.discStarter = discStarter;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public String getTag() {
        return tag;
    }
}
