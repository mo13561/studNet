import java.util.UUID;
public class mainPage {
    public static void main(String[] args) {
        String uniqueID = UUID.randomUUID().toString();
        System.out.println(uniqueID);
    }
}
